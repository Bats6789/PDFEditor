package edu.uab.cwingard.pdfeditorguis;

import java.io.IOException;
import javafx.fxml.FXML;

public class MainMenu {

    @FXML
    private void switchToMerger() throws IOException {
        App.setRoot("secondary");
    }
    
    @FXML
    private void switchToTextExtractor() throws IOException {
        App.setRoot("TextExtractor");
    }
}
