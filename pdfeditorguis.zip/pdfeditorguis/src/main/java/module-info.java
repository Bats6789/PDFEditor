module edu.uab.cwingard.pdfeditorguis {
    requires javafx.controls;
    requires javafx.fxml;

    opens edu.uab.cwingard.pdfeditorguis to javafx.fxml;
    exports edu.uab.cwingard.pdfeditorguis;
}