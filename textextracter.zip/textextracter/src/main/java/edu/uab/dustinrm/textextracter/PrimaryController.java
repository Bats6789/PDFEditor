package edu.uab.dustinrm.textextracter;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Spinner;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import javafx.stage.FileChooser;
import javafx.fxml.FXML;
import java.io.File;
import javafx.stage.Window;
import java.io.FileWriter;
import java.io.IOException;
import javafx.scene.layout.VBox;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.pdmodel.PDDocument;

public class PrimaryController {
    @FXML private Button browseFileButton;
    @FXML private VBox windowPane;
    @FXML private Label fileLabel;
    @FXML private TextField startPage;
    @FXML private TextField endPage;
    @FXML private Button backButton;
    @FXML private Button extractButton;
    @FXML private CheckBox pageCheck;
    @FXML private CheckBox pagesCheck;
    @FXML private TextField outputFileName;
    @FXML private Label outputFileNameLabel;
    PDDocument baseDocument;
    
    @FXML
    private void browseFile(ActionEvent event) {
        
        FileChooser fileChooser = new FileChooser();
         //adding file filters
        fileChooser.getExtensionFilters().addAll(
             new FileChooser.ExtensionFilter("PDF Documents", "*.pdf"));
        
        try{
            File basePDF = fileChooser.showOpenDialog(windowPane.getScene().getWindow());
            fileLabel.setText(basePDF.getName());
            baseDocument = PDDocument.load(basePDF);
        }catch(IOException e){
            
        }
    }

    @FXML
    private void extractByPage(ActionEvent event) {
        startPage.setEditable(true);
    }

    @FXML
    private void extractText(ActionEvent event) {
        try{
            File outputFile = new File(outputFileName.getText());
            PDFTextStripper extract = new PDFTextStripper();
            FileWriter writer = new FileWriter(outputFile); 
            if(pageCheck.selectedProperty().get()){
                //extracting a single page
                extract.setStartPage(Integer.parseInt(startPage.getCharacters().toString()));
                extract.setEndPage(Integer.parseInt(startPage.getCharacters().toString()));
                String extractedText = extract.getText(baseDocument);
                writer.write(extractedText);
                writer.close();
            }else if(pagesCheck.selectedProperty().get()){
                //extracting multiple pages
                extract.setStartPage(Integer.parseInt(startPage.getCharacters().toString()));
                extract.setEndPage(Integer.parseInt(endPage.getCharacters().toString()));
                String extractedText = extract.getText(baseDocument);
                writer.write(extractedText);
                writer.close();
            }else{
                //extracting everything
                String extractedText = extract.getText(baseDocument);
                writer.write(extractedText);
                writer.close();
            }
        }catch(IOException e){
            
        }
    }

    @FXML
    private void backButton(ActionEvent event) {
    }

    @FXML
    private void extractByPages(ActionEvent event) {
        endPage.setEditable(true);
    }

    @FXML
    private void fileNameEnter(ActionEvent event) {
       outputFileNameLabel.setText(outputFileName.getText()); 
    }
    
}
