module edu.uab.dustinrm.textextracter {
    requires javafx.controls;
    requires javafx.fxml;

    opens edu.uab.dustinrm.textextracter to javafx.fxml;
    exports edu.uab.dustinrm.textextracter;
}